<?php

function conectarBD():mysqli{ // ": mysqli" indica que esta funcion debera retornar una conexion de mysli
    $bd=mysqli_connect('localhost', 'root', '', 'magna');

    if(!$bd){
        echo 'ERROR DE CONEXION :c';
        exit; //Se encarga de que no se ejecute el demas codigo en caso de que no se pueda conectar
    }

    return $bd;
}