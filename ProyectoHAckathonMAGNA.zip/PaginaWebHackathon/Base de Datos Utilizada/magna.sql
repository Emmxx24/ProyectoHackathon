-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-11-2024 a las 09:43:53
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `magna`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalcularAntiguedad` (IN `p_idTrabajador` VARCHAR(10))  BEGIN
    DECLARE current_year INT;
    DECLARE current_month INT;
    DECLARE ingreso_year INT;
    DECLARE ingreso_month INT;
    DECLARE salida_year INT;
    DECLARE salida_month INT;
    DECLARE antiguedad_calculada INT;

    -- Obtener año y mes actuales
    SET current_year = YEAR(CURDATE());
    SET current_month = MONTH(CURDATE());

    -- Obtener año y mes de FechaIngreso
    SELECT YEAR(FechaIngreso), MONTH(FechaIngreso)
    INTO ingreso_year, ingreso_month
    FROM Empleado
    WHERE idTrabajador = p_idTrabajador;

    -- Si FechaSalida es NULL, usar la fecha actual
    IF (SELECT FechaSalida FROM Empleado WHERE idTrabajador = p_idTrabajador) IS NULL THEN
        SET antiguedad_calculada = (current_year - ingreso_year) * 12 + (current_month - ingreso_month);
    ELSE
        -- Si tiene FechaSalida, calcular la antigüedad hasta esa fecha
        SELECT YEAR(FechaSalida), MONTH(FechaSalida)
        INTO salida_year, salida_month
        FROM Empleado
        WHERE idTrabajador = p_idTrabajador;
        SET antiguedad_calculada = (salida_year - ingreso_year) * 12 + (salida_month - ingreso_month);
    END IF;

    -- Actualizar la antigüedad del empleado
    UPDATE Empleado
    SET Antiguedad = antiguedad_calculada
    WHERE idTrabajador = p_idTrabajador;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalcularEdad` (IN `emp_id` VARCHAR(10))  BEGIN
    DECLARE current_year INT;
    DECLARE birth_year INT;
    DECLARE birth_month INT;
    DECLARE current_month INT;
    DECLARE edad_calculada INT;

    -- Obtener el año y el mes actuales
    SET current_year = YEAR(CURDATE());
    SET current_month = MONTH(CURDATE());

    -- Obtener el año y el mes de nacimiento del empleado
    SET birth_year = (SELECT YEAR(FechaNacimiento) FROM Empleado WHERE idTrabajador = emp_id);
    SET birth_month = (SELECT MONTH(FechaNacimiento) FROM Empleado WHERE idTrabajador = emp_id);

    -- Calcular la edad en años considerando si ya cumplió años este año
    SET edad_calculada = current_year - birth_year;

    IF current_month < birth_month THEN
        SET edad_calculada = edad_calculada - 1;
    END IF;

    -- Actualizar el campo Edad en la tabla Empleado
    UPDATE Empleado
    SET Edad = edad_calculada
    WHERE idTrabajador = emp_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `idCategoria` int(11) NOT NULL,
  `Categoria` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`idCategoria`, `Categoria`) VALUES
(1, 'DIR'),
(2, 'IND');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clasificacion`
--

CREATE TABLE `clasificacion` (
  `idClasificacion` int(11) NOT NULL,
  `Clasificacion` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clasificacion`
--

INSERT INTO `clasificacion` (`idClasificacion`, `Clasificacion`) VALUES
(1, 'EMP'),
(2, 'OPE'),
(3, 'TEC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `idDepartamento` int(11) NOT NULL,
  `Departamento` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`idDepartamento`, `Departamento`) VALUES
(1, 'CALIDAD'),
(2, 'ENSAMBLE'),
(3, 'INGENIERIA'),
(4, 'LOGISTICA'),
(5, 'PRENSAS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `descripcionpuesto`
--

CREATE TABLE `descripcionpuesto` (
  `idPuesto` int(11) NOT NULL,
  `Descripcion` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `descripcionpuesto`
--

INSERT INTO `descripcionpuesto` (`idPuesto`, `Descripcion`) VALUES
(1, 'Customer Service JR'),
(2, 'Ingeniero de Calidad Proyectos'),
(3, 'Ingeniero de Calidad Proyectos'),
(4, 'Ingeniero de Manufactura'),
(5, 'Operador'),
(6, 'Operador Líder'),
(7, 'Operador Líder Recursos Humano'),
(8, 'Operador Soldador'),
(9, 'Planeador de Materiales'),
(10, 'Program Manager'),
(11, 'Team Leader'),
(12, 'Técnico de Logística'),
(13, 'Técnico de Logística SR');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `idTrabajador` varchar(30) NOT NULL,
  `Nombre` varchar(30) DEFAULT NULL,
  `ApellidoPat` varchar(30) DEFAULT NULL,
  `ApellidoMat` varchar(30) DEFAULT NULL,
  `FechaIngreso` date DEFAULT NULL,
  `Antiguedad` int(11) DEFAULT NULL,
  `FechaSalida` date DEFAULT NULL,
  `FechaNacimiento` date DEFAULT NULL,
  `Edad` int(11) DEFAULT NULL,
  `Domicilio` varchar(50) DEFAULT NULL,
  `Colonia` varchar(30) DEFAULT NULL,
  `CodigoPostal` int(11) DEFAULT NULL,
  `Sexo` char(1) DEFAULT NULL,
  `idCategoria` int(11) DEFAULT NULL,
  `idClasificacion` int(11) DEFAULT NULL,
  `idDepartamento` int(11) DEFAULT NULL,
  `idDescPuesto` int(11) DEFAULT NULL,
  `idEstado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`idTrabajador`, `Nombre`, `ApellidoPat`, `ApellidoMat`, `FechaIngreso`, `Antiguedad`, `FechaSalida`, `FechaNacimiento`, `Edad`, `Domicilio`, `Colonia`, `CodigoPostal`, `Sexo`, `idCategoria`, `idClasificacion`, `idDepartamento`, `idDescPuesto`, `idEstado`) VALUES
('B000013751', 'JUAN ANTONIO', 'REBOLLOZA', 'ESQUIVEL', '2024-01-08', 7, '2024-08-09', '1992-12-02', 31, 'ARQUIMIDES 225', 'PROGRESO', 78370, 'M', 1, 2, 2, 5, 4),
('B000013752', 'JUAN CARLOS', 'ALONZO', 'AGUILAR', '2024-01-08', 3, '2024-04-22', '2001-10-07', 23, 'INDEPENDENCIA 210', 'BENITO JUAREZ', 37610, 'M', 1, 2, 2, 5, 4),
('B000013753', 'VICTOR FERNANDO', 'MAYA', 'GUTIERREZ', '2024-01-08', 3, '2024-04-04', '1999-02-21', 25, 'CUAUHTEMOC 24', 'NEGRETE', 79525, 'M', 1, 2, 2, 5, 4),
('B000013768', 'JEANETTE ARACELI', 'CONTRERAS', 'MONREAL', '2024-01-15', 2, '2024-03-15', '1999-07-29', 25, 'TENERIA  313A', 'LOMAS DL FILTROS', 78219, 'F', 1, 2, 2, 6, 4),
('B000013773', 'JUAN ANTONIO', 'PACHECO', 'GALICIA', '2024-01-22', 6, '2024-07-04', '1989-05-07', 35, 'PRIV. CRUZ DE MADERA  303A', 'FRACC. CONJUNTO DEL REAL', 78438, 'M', 2, 1, 4, 11, 4),
('B000013785', 'JAVIER', 'RODRIGUEZ', 'RIVERA', '2024-01-29', 4, '2024-05-10', '1983-09-17', 41, 'HIDALGO 53', 'EL SAUCILLO', 79511, 'M', 1, 2, 2, 5, 4),
('B000013787', 'JUANA YANET', 'SANDOVAL', 'CORTES', '2024-01-29', 2, '2024-03-19', '1994-08-17', 30, 'EL TEJOCOTE', 'EL TEJOCOTE', 37611, 'F', 1, 2, 2, 5, 1),
('B000013788', 'JUAN', 'RUIZ', 'PEREZ', '2024-01-29', 2, '2024-03-01', '1974-11-17', 50, 'EXT EST JARAL CALLE PRINCIPAL', 'JARAL DEL BERRIO', 37611, 'F', 1, 2, 2, 5, 1),
('B000013791', 'JOSHUA ALEJANDRO', 'BELMARES', 'CARREON', '2024-01-29', 9, '2024-10-04', '2005-06-22', 19, 'DOMINICANA 0106', 'FRACC MISION DEL PALMAR', 78394, 'M', 1, 2, 2, 5, 4),
('B000013793', 'OSIAS DE JESUS', 'OLIVA', 'GUTIERREZ', '2024-01-29', 3, '2024-04-02', '2001-03-05', 23, 'DE LA CRUZ 10', 'LAGUNA SN VICENTE', 79525, 'M', 1, 2, 2, 5, 4),
('B000013794', 'MARIANA LIZBETH', 'PEREZ', 'MARTINEZ', '2024-01-29', 3, '2024-04-22', '1996-06-09', 28, 'FLORIDA 101', 'SAN BARTOLO DE BERRIO', 37610, 'F', 1, 2, 2, 5, 1),
('B000013796', 'NOEMI', 'GONZALEZ', 'TERAN', '2024-01-29', 3, '2024-04-04', '1993-09-08', 31, 'CAMINO A LA MESITA 11', 'CALDERON', 79530, 'F', 1, 2, 2, 5, 4),
('B000013798', 'SUJEY VIRIDIANA', 'LOPEZ', 'ALDERETE', '2024-01-29', 2, '2024-03-15', '1991-12-02', 32, 'AND TARAHUMARAS 3 D', 'HOG FERR 2A SECC', 78436, 'F', 1, 2, 2, 5, 4),
('B000013801', 'JUAN DANIEL', 'RAMIREZ', 'ALMENDARIZ', '2024-02-06', 6, '2024-08-19', '1997-04-27', 27, 'FRANCISCO VILLA 27', 'EL PEDREGAL', 79540, 'M', 1, 2, 2, 5, 4),
('B000013803', 'VICTOR ALFONSO', 'SEGURA', 'MOLINA', '2024-02-06', 1, '2024-03-01', '1994-06-23', 30, 'EL ROSARIO 45', 'JARAL DE BERRIO', 37611, 'M', 1, 2, 2, 5, 1),
('B000013804', 'FATIMA CAROLINA', 'MENDOZA', 'GONZALEZ', '2024-02-06', 1, '2024-03-19', '2005-01-21', 19, 'LOS MACHEROS 9', 'RANCHO LOS MACHEROS', 79532, 'F', 1, 2, 2, 5, 4),
('B000013805', 'LIZETH GUADALUPE', 'BRIONES', 'ARRIAGA', '2024-02-06', 1, '2024-03-06', '2005-01-19', 19, 'LIRIO 7', 'VEC EFIGENIA CARREON', 79524, 'F', 1, 2, 2, 5, 4),
('B000013806', 'NADIA ISABEL', 'SAAVEDRA', 'LARA', '2024-02-06', 5, '2024-07-01', '2003-02-07', 21, 'EJIDO LEQUEITIO', 'GUADALUPE', 37611, 'F', 1, 2, 2, 5, 4),
('B000013810', 'MIGUEL ANGEL', 'MENDEZ', 'ROQUE', '2024-02-06', 2, '2024-04-30', '1999-09-04', 25, 'MALASIA 1033', 'SIMON DIAZ', 78380, 'M', 2, 3, 4, 5, 4),
('B000013823', 'CLAUDIA DANIELA', 'PIÑON', 'ACOSTA', '2024-02-12', 1, '2024-03-15', '1992-07-21', 32, 'ARBOLITOS 206', 'JARAL DE BERRIO', 37611, 'F', 1, 2, 2, 12, 1),
('B000013824', 'JUAN PABLO', 'HORTA', 'GUERRERO', '2024-02-12', 3, '2024-05-13', '2000-07-17', 24, 'LA MERCED', 'JARAL DE BERRIO', 37611, 'M', 1, 2, 2, 5, 1),
('B000013853', 'MANUEL ALEJANDRO', 'IBARRA', 'GONZALEZ', '2024-03-04', 2, '2024-05-20', '1994-06-16', 30, 'PZA CHICHENITZA 103', 'HOG FERR 2A SECC.', 78436, 'M', 1, 2, 2, 5, 4),
('B000013868', 'ISAAC', 'DIAZ', 'JONGUITUD', '2024-03-19', 3, '2024-06-14', '2000-05-08', 24, 'COMONFORT 1230 7 12', 'ALAMITOS', 78280, 'M', 2, 1, 4, 5, 4),
('B000013879', 'JOSE DE JESUS', 'MENDEZ', 'CASTILLO', '2024-03-25', 3, '2024-06-23', '1991-03-31', 33, 'FCO. MTZ DE LA VEGA 506', 'FRACC. INDUSTRIAS', 78399, 'M', 2, 1, 2, 1, 4),
('B000013903', 'FERNANDO', 'GARCIA', 'SEGURA', '2024-04-08', 5, '2024-09-12', '1986-11-05', 38, 'ISMAEL RAMOS RANGEL 8', 'EL ROSARIO', 79500, 'M', 2, 3, 4, 11, 4),
('B000013916', 'JESUS MANUEL', 'MONTEMAYOR', 'MARTINEZ', '2024-04-15', 1, '2024-05-10', '1996-01-23', 28, 'MANUEL GONZALEZ AZCARATE 196 3', 'HIMNO NACIONAL 2A. SECCION', 78280, 'M', 2, 1, 1, 12, 4),
('B000013918', 'JONATHAN ALEXIS', 'AGUILAR', 'CERDA', '2024-04-15', 1, '2024-05-20', '1998-10-29', 26, 'VISTA  CRISTAL 167', 'VISTA BELLA', 66005, 'M', 2, 3, 4, 2, 2),
('B000013932', 'LUIS ILDEFONSO', 'CISNEROS', 'TURRUBIARTES', '2024-04-22', 3, '2024-07-27', '1991-11-22', 33, 'AV. GRANJAS 321', 'RETORNOS', 78140, 'M', 2, 1, 1, 13, 4),
('B000013933', 'EDGAR', 'JUAREZ', 'NAVA', '2024-04-22', 3, '2024-07-02', '1977-03-29', 47, 'PV MATAMOROS B 9404', 'FRAC VFR. REVOLUCION MEXICANA', 72200, 'M', 2, 1, 1, 2, 3),
('B000013947', 'JOSE RAMON', 'MALDONADO', 'GARCIA', '2024-04-29', 2, '2024-06-11', '1999-06-10', 25, 'BLVD ORQUIDEA PONIENTE 71 CP 7', 'POZARREAL, SLP', 78394, 'M', 2, 3, 4, 3, 4),
('B000013950', 'CARLOS YAHIR', 'FRIAS', 'PIÑON', '2024-04-29', 4, '2024-08-05', '2004-01-12', 20, 'ENTRADA  A CARRETON', 'ESTANCIA DE CARRETON', 37611, 'M', 1, 2, 2, 12, 1),
('B000013953', 'CARLOS', 'SAAVEDRA', 'MARTINEZ', '2024-04-29', 1, '2024-05-14', '1974-03-16', 50, 'RIO SILAO 104', 'PPAL TURIDIA', 37611, 'M', 1, 2, 5, 5, 1),
('B000013958', 'RAYMUNDO', 'RUBIO', 'GARCIA', '2024-05-06', 1, '2024-06-14', '2002-05-15', 22, 'AMPL DEL ZAPOTE', 'ZAPOTE', 37611, 'M', 1, 2, 2, 5, 1),
('B000013959', 'LIZETH ESMERALDA', 'CAMARILLO', 'RUIZ', '2024-05-06', 1, '2024-06-14', '2003-10-12', 21, 'HIDALGO SN', 'SAN BARTOLO DE BERRIO', 37611, 'M', 1, 2, 2, 5, 1),
('B000013960', 'NEREYDA', 'RODRIGUEZ', 'CORONA', '2024-05-06', 2, '2024-07-19', '1995-03-06', 29, 'REYNOSA 404', 'SAN BARTOLIO DE BERRIO', 37611, 'F', 1, 2, 2, 5, 1),
('B000013967', 'OMAR', 'ROCHA', 'ZACARIAS', '2024-05-13', 1, '2024-06-11', '1991-09-12', 33, 'CALLE PRINCIPAL', 'LEQUEITO', 37611, 'M', 2, 3, 4, 5, 1),
('B000013970', 'ROCIO', 'ROSTRO', 'ACOSTA', '2024-05-13', 1, '2024-06-03', '1998-09-28', 26, 'POR LA ESCUELA SN', NULL, NULL, 'F', 1, 2, 2, 12, 1),
('B000013971', 'JOSE LUIS', 'ORTIZ', 'RODRIGUEZ', '2024-05-13', 3, '2024-08-12', '1994-12-17', 29, 'EL ZAPOTE SN', NULL, 37611, 'M', 1, 2, 2, 5, 1),
('B000013972', 'ARACELI GUADALUPE', 'MARTINEZ', 'ORTIZ', '2024-05-13', 1, '2024-06-23', '1998-09-06', 26, 'ESTANCIA DE CARRETON', NULL, 37611, 'F', 1, 2, 2, 5, 1),
('B000013987', 'MONICA', 'RODRIGUEZ', 'FRIAS', '2024-05-27', 3, '2024-08-28', '1996-03-13', 28, 'ESCOBEDO', NULL, 37610, 'M', 1, 2, 2, 5, 1),
('B000013988', 'RAUL', 'CASTILLO', 'ORTIZ', '2024-05-27', 3, '2024-08-19', '1993-08-28', 31, 'LA MERCED SN', NULL, 37611, 'M', 1, 2, 5, 5, 1),
('B000014000', 'ANA KAREN', 'ACEVEDO', 'LONGORIA', '2024-06-10', 1, '2024-07-11', '1989-12-01', 34, 'PRIV MURATA  0481', 'MURATA RESIDENCIAL', 78394, 'F', 2, 1, 3, 5, 4),
('B000014010', 'JOSUE LEONARDO', 'RODRIGUEZ', 'RUEDA', '2024-06-17', 2, '2024-08-26', '2003-01-10', 21, 'INDEPENDENCIA 14', 'GUERRERO', 79511, 'M', 1, 2, 2, 10, 4),
('B000014015', 'EDITH MARCELA', 'GUZMAN', 'DE BLAS', '2024-06-17', 3, '2024-09-12', '1984-06-18', 40, 'DOMINIOS DEL CANADA 124', 'SATELITE', 78380, 'F', 1, 2, 2, 5, 4),
('B000014018', 'EDSON ANDRES', 'OROPEZA', 'GARCIA', '2024-06-24', 3, '2024-09-20', '1988-04-02', 36, 'CTO PALMA DE CHILE 103 A', 'VALLE DE LA PALMA', 78439, 'M', 2, 1, 4, 5, 4),
('B000014023', 'MAYRA EDIHT', 'MARTINEZ', 'CAMARILLO', '2024-06-24', 3, '2024-09-09', '1988-06-03', 36, 'AMPL DEL ZAPOTE', 'ZAPOTE', 37611, 'F', 1, 2, 2, 9, 1),
('B000014025', 'GERARDO', 'RAMIREZ', 'ORTIZ', '2024-06-24', 2, '2024-08-20', '1998-06-21', 26, 'VEC PEDRO RAMIREZ ARRIAGA', 'LAGUNA SAN VICENTE', 79525, 'M', 1, 2, 2, 5, 4),
('B000014032', 'CAMILA', 'VELAZQUEZ', 'HERNANDEZ', '2024-07-01', 2, '2024-09-20', '2003-08-28', 21, 'GRAL VON MOLTKE 147', 'MARIA CECILIA', 78117, 'F', 1, 2, 2, 5, 4),
('B000014076', 'EVELIN ESTRELLA', 'GUTIÉRREZ', 'GONZALEZ', '2024-07-15', 1, '2024-08-28', '1986-06-20', 38, '2A PRIV DE PALMERAL 113 A', 'MISION DL PALMAR', 78394, 'F', 1, 2, 5, 7, 4),
('B000014098', 'JOSE LUIS', 'SEGURA', 'LOPEZ', '2024-07-22', 1, '2024-08-26', '1982-11-20', 42, 'PRIV LA  MERCED 102', NULL, 37611, 'M', 2, 3, 4, 5, 1),
('B000014167', 'LUIS ADAN', 'GARCIA', 'MARTINEZ', '2024-08-12', 2, '2024-10-25', '2002-09-10', 22, '27 DE MARZO 100', NULL, 37611, 'M', 1, 2, 2, 12, 1),
('B000014168', 'JESUS SAGRARIO', 'TERAN', 'SEGURA', '2024-08-12', -24296, '0000-00-00', '1999-04-07', 25, 'EL ZAPOTE', 'EL ZAPOTE', 37611, 'F', 1, 2, 2, 5, 1),
('B000014169', 'MAURICIO RAFAE', 'PEREZ', 'HERNANDEZ', '2024-08-12', 3, NULL, '2003-12-20', 20, 'HIDALGO 440', 'LAGUNA DE SAN VICENTE', 79525, 'M', 1, 2, 2, 5, 4),
('B000014170', 'MAURICIO RAFAEL', 'RUIZ', 'CHAIREZ', '2024-08-12', 3, NULL, '1988-09-06', 36, 'SAN FERNANDO 229 A W 6', 'RES SAUZALITO', 78116, 'M', 2, 3, 4, 13, 4),
('B000014171', 'OSCAR EDUARDO', 'MARTINEZ', 'FLORES', '2024-08-12', 2, '2024-10-11', '2004-04-18', 20, 'AV GIRASOLES 352', 'PUEBLO LIBRE', 78430, 'M', 2, 3, 4, 5, 4),
('B000014234', 'MARIA ISABEL', 'CUEVAS', 'DIAZ', '2024-09-14', 2, NULL, '1987-01-27', 37, 'TORRE DE ALCAZAR 606', 'LOS MOLINOS', 78147, 'F', 1, 2, 2, 5, 4),
('B000014235', 'ANA DANIELA', 'MARTINEZ', 'TORRES', '2024-09-17', 2, NULL, '1999-04-12', 25, 'AV DE LA PAZ SN', 'SAN CRISTOBAL', 79500, 'F', 1, 2, 2, 5, 4),
('B000014236', 'GABRIELA KARINA', 'MARTINEZ', 'ORTIZ', '2024-09-17', 2, NULL, '1997-08-08', 27, 'A UN LADO DE LA ESC PRIM SN', 'ZAPOTE', 37611, 'F', 1, 2, 2, 5, 1),
('B000014239', 'ALEXIS EDUARDO', 'ESPINOZA', 'DAVILA', '2024-09-17', 1, '2024-10-16', '1994-10-16', 30, 'VILLAS DEL POTOSI 216', 'VILLAS DEL POTOSI', 78437, 'M', 1, 2, 2, 12, 4),
('B000014240', 'IRAIS', 'NIGOCHE', 'LOPEZ', '2024-09-17', 0, '2024-09-19', '1993-03-25', 31, 'CTO SAN LUCAS 970', 'FRACC VALLE DE SAN PATRIC', 78433, 'F', 2, 1, 2, 8, 4),
('B000014250', 'OMAR BENJAMIN', 'GONZALEZ', 'ZUÑIGA', '2024-09-23', 1, '2024-10-16', '1989-09-02', 35, 'JOSE MA MORELOS 112', 'ESTANCIA DE CARRETON', 37611, 'M', 1, 2, 2, 4, 1),
('B000014267', 'JESSICA PAOLA', 'ESPINOSA', 'PADRON', '2024-10-03', 0, '2024-10-25', '1998-02-04', 26, 'MANUEL JOSE OTHON 205 B', 'VEG. JULIAN SEGURA FLORES', 79530, 'F', 1, 2, 2, 5, 4),
('B000014292', 'FELIX', 'SANDOVAL', 'BANDA', '2024-10-07', 0, '2024-10-25', '1985-03-07', 39, '10 DE MAYO 1 A', 'MIGUEL HIDALGO', 79506, 'M', 1, 2, 2, 5, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `idEstado` int(11) NOT NULL,
  `Estado` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`idEstado`, `Estado`) VALUES
(1, 'GUANAJUATO'),
(2, 'NUEVO LEON'),
(3, 'PUEBLA'),
(4, 'SAN LUIS POTOSI');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`idCategoria`);

--
-- Indices de la tabla `clasificacion`
--
ALTER TABLE `clasificacion`
  ADD PRIMARY KEY (`idClasificacion`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`idDepartamento`);

--
-- Indices de la tabla `descripcionpuesto`
--
ALTER TABLE `descripcionpuesto`
  ADD PRIMARY KEY (`idPuesto`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`idTrabajador`),
  ADD KEY `idClasificacion` (`idClasificacion`),
  ADD KEY `idEstado` (`idEstado`),
  ADD KEY `idDescPuesto` (`idDescPuesto`),
  ADD KEY `idDepartamento` (`idDepartamento`),
  ADD KEY `idCategoria` (`idCategoria`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`idEstado`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`idClasificacion`) REFERENCES `clasificacion` (`idClasificacion`),
  ADD CONSTRAINT `empleado_ibfk_2` FOREIGN KEY (`idEstado`) REFERENCES `estado` (`idEstado`),
  ADD CONSTRAINT `empleado_ibfk_3` FOREIGN KEY (`idDescPuesto`) REFERENCES `descripcionpuesto` (`idPuesto`),
  ADD CONSTRAINT `empleado_ibfk_4` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`idDepartamento`),
  ADD CONSTRAINT `empleado_ibfk_5` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`idCategoria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
