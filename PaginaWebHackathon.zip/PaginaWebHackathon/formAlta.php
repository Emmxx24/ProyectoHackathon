<?php
require 'conexionBD.php';
//require 'iniciarSesion.php';
$bd=conectarBD();
$errores=[];
$id="";
$nombre="";
$ApP="";
$ApM = "";
$ingreso="";
$nacimiento="";
$categoria="";
$clasificacion ="";
$departamento="";
$puesto="";
$domicilio="";
$cp = "";
$colonia="";
$estado = "";
$sexo="";



if($_SERVER['REQUEST_METHOD']==='POST'){
    $id=$_POST['id'];
    $nombre=$_POST['nombre'];
    $ApP=$_POST['ApP'];
    $ApM = $_POST['ApM'];
    $ingreso=$_POST['ingreso'];
    $nacimiento=$_POST['nacimiento'];
    $categoria=$_POST['categoria'];
    $clasificacion =$_POST['clasificacion'];
    $departamento=$_POST['departamento'];
    $puesto=$_POST['puesto'];
    $domicilio=$_POST['domicilio'];
    $cp = $_POST['cp'];
    $colonia=$_POST['colonia'];
    $estado = $_POST['estado'];
    $sexo=$_POST['genero'];

    if(!$id or !$nombre or !$ingreso or !$nacimiento or !$domicilio or !$cp or !$colonia){
        $errores[]="Faltan campos por llenar";
    }

    if(empty($errores)){
        $query="INSERT INTO empleado (idTrabajador, Nombre, ApellidoPat, ApellidoMat, FechaIngreso, FechaSalida, FechaNacimiento, Domicilio, Colonia, CodigoPostal, Sexo, idCategoria, idClasificacion, idDepartamento, idDescPuesto, idEstado) 
        VALUES ('$id', '$nombre', '$ApP' ,'$ApM', '$ingreso', NULL,'$nacimiento', '$domicilio', '$colonia', '$cp', '$sexo','$categoria', '$clasificacion', '$departamento', '$puesto', '$estado');";

        $resultado=mysqli_query($bd, $query);

        echo $query;

        if($resultado){
            //Si lo logro insertar, se realizan los calculos de edad y antiguedad
            mysqli_query($bd, "CALL CalcularAntiguedad('$id');");
            mysqli_query($bd, "CALL CalcularEdad('$id');");
            header('Location: index.php');
        }
    }
}

?>


<!DOCTYPE html>
<html lang="es">
<div class="item">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alta empleado</title>
  <link rel="stylesheet" href="EstiloHackathon.css">
</head>
  <body>
    <header>
        <a href="https://www.magna.com/es">
            <img src="magnalogo.png" alt="Logo de Magna" id="Logo">
        </a>
      <div class="Lema">
        <h2><span id="LemaB">BETTER MOBILITY.</span><span>It Matters.</span></h2>
      </div>
    </header>

    <main>
      <section>
        <h2>Alta</h2>
        <form class="Alta" method="POST" enctype="multipart/form-data">
            <label>Id: 
            <input type="text" id="id" name="id"  step="1" required></label>

            <label>Nombres: 
            <input type="text" id="nombre" name="nombre" required></label>

            <label>Apellido Paterno: 
            <input type="text" id="ApP" name="ApP" required></label>

            <label>Apellido Materno: 
            <input type="text" id="ApM" name="ApM" required></label>
            
            <label>Ingreso: 
            <input type="date" id="ingreso" name="ingreso" required></label>

            <label>Nacimiento: 
            <input type="date" id="nacimiento" name="nacimiento" required></label>
            
            <label>Categoria:
            <select name="categoria" id="categoria">
            <?php
            $query = "SELECT * FROM categoria";
            $resultado = mysqli_query($bd, $query);
            while($dato = mysqli_fetch_assoc($resultado)):
                echo '<option value="' . $dato["idCategoria"] . '" >' . $dato["Categoria"] . '</option>';
            
            endwhile;
            ?>
            </select></label>

            <label>Clasificacion:
            <select name="clasificacion" id="clasificacion">
            <?php
            $query = "SELECT * FROM clasificacion";
            $resultado = mysqli_query($bd, $query);
            while($dato = mysqli_fetch_assoc($resultado)):
                echo '<option value="' . $dato["idClasificacion"] . '">' . $dato["Clasificacion"] . '</option>';
            
            endwhile;
            ?>
            </select></label>

            <label>Departamento:
            <select name="departamento" id="departamento">
            <?php
            $query = "SELECT * FROM departamento";
            $resultado = mysqli_query($bd, $query);
            while($dato = mysqli_fetch_assoc($resultado)):
                echo '<option value="' . $dato["idDepartamento"] . '">' . $dato["Departamento"] . '</option>';
            
            endwhile;
            ?>
            </select></label>

            <label>Puesto:
            <select name="puesto" id="puesto">
            <?php
            $query = "SELECT * FROM descripcionpuesto";
            $resultado = mysqli_query($bd, $query);
            while($dato = mysqli_fetch_assoc($resultado)):
                echo '<option value="' . $dato["idPuesto"] . '">' . $dato["Descripcion"] . '</option>';
            
            endwhile;
            ?>
            </select></label>

            <label>Domicilio: 
            <input type="text" id="domicilio" name="domicilio" required></label>

            <label>Colonia: 
            <input type="text" id="colonia" name="colonia"  required></label>

            <label>C.P.: 
            <input type="Number" id="cp" name="cp" step="1" inputmode="numeric" pattern="[0-9]*" title="Solo números" required></label>

            <label>Estado: 
            <select name="estado" id="estado">
            <?php
            $query = "SELECT * FROM estado";
            $resultado = mysqli_query($bd, $query);
            while($dato = mysqli_fetch_assoc($resultado)):
                echo '<option value="' . $dato["idEstado"] . '">' . $dato["Estado"] . '</option>';
            
            endwhile;
            ?>
            </select></label>

            <label>Sexo: 
                <span for="masculino" class="genero">
                <input type="radio" id="masculino" name="genero" value="M" class="genero" require>
                Masculino</span>
                <span for="femenino" class="genero">
                <input type="radio" id="femenino" name="genero" value="F" class="genero">
                Femenino</span>
            </label>

            <input type="submit" name="" id="" class="login-button" value="Realizar Alta">

        </form>

        <?php foreach($errores as $error):   ?>
                    <p class="alerta" style="margin-top:10px;">   
        <?php echo $error;?>
                    </p>                    
        <?php endforeach; ?>   

        <a href="index.php" class = "button">Regresar</a>
      </section>
    </main>

    <footer>
      <p>&copy; Hackathon 2024</p>
    </footer>

    <script src="ScripsHackathon.js"></script>
  </body>
  </div>
</html>