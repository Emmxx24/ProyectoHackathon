<?php
//require 'iniciarSesion.php';
require 'conexionBD.php';
$bd=conectarBD();

$query="SELECT * FROM empleado Where FechaSalida IS NULL";
$resultado=mysqli_query($bd, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lista empleados</title>
  <link rel="stylesheet" href="EstiloHackathon.css">
</head>
<body>
  <header>
    <a href="https://www.magna.com/es">
      <img src="magnalogo.png" alt="Logo de Magna" id="Logo">
    </a>
    <div class="Lema">
      <h2><span id="LemaB">BETTER MOBILITY.</span><span>It Matters.</span></h2>
    </div>
  </header>

  <main>
    <section>
      <a href="index.php" class="button">Regresar</a>
      <h2>Trabajadores</h2>
      <div class="ContenidoTabla">
        <div class="DesplazamientoTabla">
          <table>
            <thead>
              <tr>
                <th>ID Trabajador</th>
                <th>Nombre</th>
                <th>Departamento</th>
                <th>Puesto</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
            <?php while($empleado=mysqli_fetch_assoc($resultado)):?>
              <tr>
                <td><b><?php echo " ".$empleado['idTrabajador'];?></b></td>
                <td><?php echo "  ".$empleado['Nombre']." ".$empleado['ApellidoPat']." ".$empleado['ApellidoMat']; ?></td>
                <td>
                    <?php   
                      $sql = "SELECT Departamento FROM departamento WHERE idDepartamento = '" . $empleado["idDepartamento"] . "'"; 
                      $result = mysqli_query($bd, $sql);
                      $result = mysqli_fetch_assoc($result);
            
                      echo $result["Departamento"];            
            
                    ?>  
                </td>
                <td>
                    <?php   
                      $sql = "SELECT Descripcion FROM descripcionpuesto WHERE idPuesto = '" . $empleado["idDescPuesto"] . "'"; 
                      $result = mysqli_query($bd, $sql);
                      $result = mysqli_fetch_assoc($result);
            
                      echo $result["Descripcion"];            
            
                    ?>  
                </td>
                <td><a href="infoEmpleado.php?id=<?php echo $empleado['idTrabajador']?>" class ="button">Analizar</a></td>
              </tr>
            <?php endwhile;?>
            </tbody>
          </table>
        </div>
      </div>
      <h3>&lt;1&gt;</h3>
    </section>
  </main>

  <footer>
    <p>&copy; Hackathon 2024</p>
  </footer>

  <script src="ScripsHackathon.js"></script>
</body>
</html>