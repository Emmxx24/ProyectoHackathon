<?php
require 'conexionBD.php';

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio</title>
  <link rel="stylesheet" href="EstiloHackathon.css">
</head>
    <body>
    <header>
        <a href="https://www.magna.com/es">
            <img src="magnalogo.png" alt="Logo de Magna" id="Logo">
        </a>
        <div class="Lema">
        <h2><span id="LemaB">BETTER MOBILITY.</span><span>It Matters.</span></h2>
        </div>
    </header>

    <main>
        <section>
            <h2>Gestión de Personal</h2>
            <div class="contenedor">
                <a href="mostrarTrabajadores.php" class = "button">Ver empleados</a>
                <a href="formAlta.php" class = "button">Alta empleado</a>
                
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; Hackathon 2024</p>
    </footer>

    <script src="ScripsHackathon.js"></script>
    </body>
</html>