<?php
require 'conexionBD.php';
//require 'iniciarSesion.php';
$bd = conectarBD();
$porcentajeRiesgo = 0;
$pesoPuesto = 30;
$pesoDistancia = 35;
$pesoEdad = 15;
$pesoDepartamento = 20;
$porcentajeRiesgoPuesto = 0;
$porcentajeRiesgoDista = 0;
$porcentajeRiesgoEdad = 0;
$porcentajeRiesgoDepart = 0;

$id=$_GET['id'];

if(!$id){
    header('location:mostrarTrabajadores.php');
}

    
    // Suponiendo que ya tienes la conexión $bd
    $sql = "SELECT * FROM empleado WHERE idTrabajador = '" . $id . "'";
    $result = mysqli_query($bd, $sql); // Ejecutar la consulta

    if ($result->num_rows > 0) {
        $info = mysqli_fetch_assoc($result);
                

        // Número mayor de empleados por puesto
        $numeroMayorEmpleadosPuesto = "SELECT COUNT(*) AS numero_de_repeticiones
                                       FROM Empleado e
                                       JOIN DescripcionPuesto dp ON e.idDescPuesto = dp.idPuesto
                                       Where e.FechaSalida IS NOT NULL
                                       GROUP BY dp.Descripcion
                                       ORDER BY numero_de_repeticiones DESC
                                       LIMIT 1;";
        
        // Número de empleados con fecha de salida no nula por puesto
        $numeroEmpleadosPuesto = "SELECT COUNT(*) AS numero_de_repeticiones
                                  FROM Empleado e WHERE e.FechaSalida IS NOT NULL AND e.idDescPuesto = " . $info['idDescPuesto'] . ";";
        
        $r1 = mysqli_query($bd, $numeroMayorEmpleadosPuesto);
        $r2 = mysqli_query($bd, $numeroEmpleadosPuesto);

        $r1Data = mysqli_fetch_assoc($r1);
        $r2Data = mysqli_fetch_assoc($r2);

        // Calcular el porcentaje de riesgo basado en el puesto
        if ($r2Data['numero_de_repeticiones'] > 0) {
            $porcentajeRiesgoPuesto = ($r2Data["numero_de_repeticiones"] / $r1Data["numero_de_repeticiones"]) * $pesoPuesto;
        }

        // Calcular el porcentaje de riesgo basado en la distancia
        //Aqui obtener la distancia mediante la API en Python
        /*
        if ($info["distancia"] > 35) {
            $porcentajeRiesgo += $pesoDistancia;
        } else if ($info["distancia"] > 30) {
            $porcentajeRiesgo += $pesoDistancia * 0.7;
        } else if ($info["distancia"] > 25) {
            $porcentajeRiesgo += $pesoDistancia * 0.5;
        } else if ($info["distancia"] > 20) {
            $porcentajeRiesgo += $pesoDistancia * 0.3;
        }*/

        // Calcular el porcentaje de riesgo basado en la edad
        if ($info["Edad"] >= 18 && $info["Edad"] <= 30) {
            $porcentajeRiesgoEdad= $pesoEdad;
        } else if ($info["Edad"] >= 31 && $info["Edad"] <= 45) {
            $porcentajeRiesgoEdad= $pesoEdad * 0.6;
        } else if ($info["Edad"] >= 46) {
            $porcentajeRiesgoEdad = $pesoEdad;
        }

        // Número mayor de empleados por departamento
        $numeroMayorEmpleadosDep = "SELECT COUNT(*) AS numero_de_repeticiones
                                    FROM Empleado e
                                    JOIN departamento dp ON e.idDepartamento = dp.idDepartamento
                                     Where e.FechaSalida IS NOT NULL
                                    GROUP BY dp.idDepartamento
                                    ORDER BY numero_de_repeticiones DESC
                                    LIMIT 1;";
        
        // Número de empleados con fecha de salida no nula por departamento
        $numeroEmpleadosDep = "SELECT COUNT(*) AS numero_de_repeticiones
                               FROM Empleado e WHERE e.FechaSalida IS NOT NULL AND e.idDepartamento = " . $info['idDepartamento'] . ";";
        
        $r1Dep = mysqli_query($bd, $numeroMayorEmpleadosDep);
        $r2Dep = mysqli_query($bd, $numeroEmpleadosDep);

        $r1DepData = mysqli_fetch_assoc($r1Dep);
        $r2DepData = mysqli_fetch_assoc($r2Dep);
        
        // Calcular el porcentaje de riesgo basado en el departamento
        if ($r2DepData['numero_de_repeticiones'] > 0) {
            $porcentajeRiesgoDepart = ($r2DepData["numero_de_repeticiones"] / $r1DepData["numero_de_repeticiones"]) * $pesoDepartamento;
        }

        $porcentajeRiesgo = $porcentajeRiesgoDepart + $porcentajeRiesgoDista + $porcentajeRiesgoEdad + $porcentajeRiesgoPuesto;
        // Se muestra el riesgo de porcentaje en la página HTML
        // En base a los puntos que se han infringido se agregará recomendaciones
    }

?>

<!DOCTYPE html>
<html lang="es">
<div class="item">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Info Empleado</title>
  <link rel="stylesheet" href="EstiloHackathon.css">
</head>
  <body>
    <header>
        <a href="https://www.magna.com/es">
            <img src="magnalogo.png" alt="Logo de Magna" id="Logo">
        </a>
      <div class="Lema">
        <h2><span id="LemaB">BETTER MOBILITY.</span><span>It Matters.</span></h2>
      </div>
    </header>

    <main>
      <section>
        <h2>Datos del Trabajador</h2>
        <div class="contenedor">
            <label class="riesgo">Id:<?php echo $info["idTrabajador"]?> </label>

            <label class="riesgo">Nombre: <?php echo "  ".$info['Nombre']." ".$info['ApellidoPat']." ".$info['ApellidoMat'];?></label>
            
            <label class="riesgo">Ingreso: <?php echo "  ".$info["FechaIngreso"]?></label>

            <label class="riesgo">Antiguedad: <?php echo "  ".$info["Antiguedad"]?> </label>

            <label class="riesgo">Nacimiento: <?php echo "  ".$info["FechaNacimiento"]?></label>

            <label class="riesgo">Edad: <?php echo "  ".$info["Edad"]?></label>

            <label class="riesgo">Categoria: 
            <?php   
            $sql = "SELECT Categoria FROM categoria WHERE idCategoria = '" . $info["idCategoria"] . "'"; 
            $result = mysqli_query($bd, $sql);
            $result = mysqli_fetch_assoc($result);
            
            echo $result["Categoria"];            
            ?>
            </label>

            <label class="riesgo">Clasificacion: 
                <?php   
                $sql = "SELECT Clasificacion FROM clasificacion WHERE idClasificacion = '" . $info["idClasificacion"] . "'"; 
                $result = mysqli_query($bd, $sql);
                $result = mysqli_fetch_assoc($result);
            
                echo $result["Clasificacion"];            
            ?>
            </label>

            <label class="riesgo">Departamento: 
                <?php   
                $sql = "SELECT Departamento FROM departamento WHERE idDepartamento = '" . $info["idDepartamento"] . "'"; 
                $result = mysqli_query($bd, $sql);
                $result = mysqli_fetch_assoc($result);
            
                echo $result["Departamento"];            
            ?>  
            </label>

            <label class="riesgo">Puesto:
            <?php   
                $sql = "SELECT Descripcion FROM descripcionpuesto WHERE idPuesto = '" . $info["idDescPuesto"] . "'"; 
                $result = mysqli_query($bd, $sql);
                $result = mysqli_fetch_assoc($result);
            
                echo $result["Descripcion"];            
            ?>      
            </label>

            <label class="riesgo">Domicilio: <?php echo $info["Domicilio"]?></label>

            <label class="riesgo">Colonia: <?php echo $info["Colonia"]?></label>

            <label class="riesgo">C.P.: <?php echo $info["CodigoPostal"]?></label>

            <label class="riesgo">Estado: 
            <?php   
                $sql = "SELECT Estado FROM estado WHERE idEstado = '" . $info["idEstado"] . "'"; 
                $result = mysqli_query($bd, $sql);
                $result = mysqli_fetch_assoc($result);
            
                echo $result["Estado"];            
            ?>  

            </label>

            <label class="riesgo">Sexo: <?php echo $info["Sexo"]?> </label>
            
          </div>

          <hr>
        
          <div class="contenedor2">
          <label class="riesgo">Riesgo de rotacion (en escala del 0% - 100%) de acuerdo a: </label> <br>
        
          <label class="riesgo">Puesto: <?php echo $porcentajeRiesgoPuesto?>  %</label>
                
          <label class="riesgo">Edad: <?php echo $porcentajeRiesgoEdad?> %</label>

          <label class="riesgo">Departamento: <?php echo $porcentajeRiesgoDepart?> %</label>

          <br>
          <label class="riesgo">Probabilidad Total de rotacion: <?php echo $porcentajeRiesgo?> %</label>

        </div>
          <hr>

        <a href="FormularioHackathon.html" class = "button">Encuesta 30 dias</a>
        <a href="Formulario60Hackathon.html" class = "button">Encuesta 60 dias</a>
        <a href="Formulario90Hackathon.html" class = "button">Encuesta 90 dias</a>
        <a href="mostrarTrabajadores.php" class = "button">Regresar</a>

      </section>
    </main>

    <footer>
      <p>&copy; Hackathon 2024</p>
    </footer>

    <script src="ScripsHackathon.js"></script>
  </body>
  </div>
</html>